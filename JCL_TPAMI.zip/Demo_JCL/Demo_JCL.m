function model=Demo_JCL
    num=5;
    noise_level=0.01;
    x1=rand(num,1)*10;
    x2=rand(num,1)*10;
    x3=rand(num,1)*10;
    y1=2*x1'+10+rand(1,num)*noise_level;
    y2=-2*x2'-7+rand(1,num)*noise_level;
    y3=1+rand(1,num)*noise_level;
    data=cell(1,3);
    data{1}=x1;
    data{2}=x2;
    data{3}=x3;
    label=cell(1,3);
    label{1}=y1;
    label{2}=y2;
    label{3}=y3;
    testdata{1}=x1(1:2);
    testdata{2}=x2(1:2);
    testdata{3}=x3(1:2);
    
    %% 
    kertype = 'linear';
    kerpar = 0;
    lambda1 = 0.1;
    lambda2 = 0.05;
    [model prediction funValue]=JCL(data,label,'linear',0,lambda1,lambda2,testdata);

   